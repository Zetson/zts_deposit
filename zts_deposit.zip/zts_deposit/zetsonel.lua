locations = {
    ["deposit1"] = {
        taxa = 50, nume = "Depozit 1", marime = 40000, pret = 1000000,
        locatii_cufere = {
            {x = 388.36904907227, y = 3586.8146972656, z = 33.29222869873},
        }
    },
    ["deposit2"] = {
        taxa = 200, nume = "Depozit 2", marime = 60000, pret = 1000000,
        locatii_cufere = {
            {x = 46.444091796875, y = 6458.7602539063, z = 31.425287246704},
        }
    },
    ["deposit3"] = {
        taxa = 100, nume = "Depozit 3", marime = 250000, pret = 1000000,
        locatii_cufere = {
            {x = -512.517578125, y = -2200.123046875, z = 6.3940262794495},
        }
    },
    ["deposit4"] = {
        taxa = 200, nume = "Depozit 4", marime = 80000, pret = 1000000,
        locatii_cufere = {
            {x = 911.31066894531, y = -1256.2835693359, z = 25.5778465271},
        }
    },
    ["deposit5"] = {
        taxa = 100, nume = "Depozit 5", marime = 80000, pret = 1000000,
        locatii_cufere = {
            {x = -1614.7346191406, y = -821.41516113281, z = 10.070293426514},
        }
    },
}

function ReadableNumber(num, places)
    local ret
    local placeValue = ("%%.%df"):format(places or 0)
    if not num then
        return 0
    elseif num >= 1000000000000 then
        ret = placeValue:format(num / 1000000000000) .. " Tril" 
    elseif num >= 1000000000 then
        ret = placeValue:format(num / 1000000000) .. " Bil" 
    elseif num >= 1000000 then
        ret = placeValue:format(num / 1000000) .. " Mil" 
    elseif num >= 1000 then
        ret = placeValue:format(num / 1000) .. "k"
    else
        ret = num 
    end
    return ret
end
