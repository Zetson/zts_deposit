local Proxy = module("vrp", "lib/Proxy")
local Tunnel = module("vrp", "lib/Tunnel")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","zts_deposit")

local cufere = {}
local cufere_ocupate = {}

local function chest_create(player, x, y, z, nume, marime, title, taxa, permissions, area)

    local user_id = vRP.getUserId({player})
    local chestName = "depozit_propriu:"..user_id..":" .. nume .. ":cufar"
    local permissions = permissions or {}

    local nid = "area:" .. chestName
    if area ~= nil then
        nid = nid..":"..area
    end

    local chest_put = function(idname, amount)
        local weight = vRP.getItemWeight({idname})
        local pret = amount * taxa
        if weight > 0.0 then
            if taxa > 0.0 then
                if vRP.tryGetInventoryItem({user_id, "cheie_cufar", 1, false}) then
                    vRPclient.notify(player, {("~y~Ai salvat ~g~$%s ~w~folosind cheia!"):format(ReadableNumber(pret, 2))})
                else
                    vRP.giveMoney({user_id, -pret})
                    vRPclient.notify(player, {("~y~TAXA: ~g~$%s ~w~(~y~x%i~w~)"):format(ReadableNumber(pret, 2), amount)})
                end
            end
        end
    end

    local chest_enter = function(player, area)
        local allowed = false
        local user_id = vRP.getUserId({player})
        if user_id then
            if not vRP.hasPermission({user_id, "zetson.perm"}) and #permissions > 0 then
                for _,perm in next, permissions do
                    if vRP.hasPermission({user_id, perm}) then
                        allowed = true
                    end
                end
            else
                allowed = true
            end
            if allowed then
                local menudata = {}
                menudata.nume = title

                menudata["<span sort='a' style='color:orange'>Deschide cufar</span>"] = {function(player)
                    vRP.openChest({player, chestName, marime * 10.0, function() end, chest_put, function() end, title})
                end, "Acceseaza cufaru"}

                vRP.openMenu({player, menudata})
            else
                vRPclient.notify(player, {"~r~Nu ai acces la cufar"})
            end
        end
    end

    local chest_leave = function(player, area)
        vRP.closeMenu({player})
    end
    -- vRP.setArea({player, nid, x, y, z, 2, 4.5, chest_enter, chest_leave})
    if not cufere[player] then
        cufere[player] = {}
    end
    cufere[player][nume] = {nid, chest_enter, chest_leave}
end

AddEventHandler("adauga:cufar", function(source, data)
    chest_create(source, data.pos.x, data.pos.y, data.pos.z, data.id, data.marime, data.nume, data.taxa, data.permissions, data.area)
    TriggerClientEvent("adauga:cufar", source, data)
end)

RegisterServerEvent("deschide:cufar")
AddEventHandler("deschide:cufar", function(nume)
    print("SE deschide ufaru " .. nume)
    if cufere[source] then
        print("Ai depus")
        if cufere[source][nume] then
            print("Ai depus " .. nume)
            cufere[source][nume][2](source)
        end
    end
end)

function make_chests(source)
    for storageId, storageData in next, locations do
        for _,coords in next, storageData.locatii_cufere do
            chest_create(source, coords.x, coords.y, coords.z, storageId, storageData.marime, storageData.nume, storageData.taxa, storageData.permissions, coords.area)
        end
    end
end

Citizen.CreateThread(function()
    local users = vRP.getUsers({})
    for user_id, player in next, users do
        make_chests(player)
    end
end)

AddEventHandler("vRP:playerSpawn", function(user_id, source, first_spawn)
    if first_spawn then
        make_chests(source)
    end
end)
